//
//  Controller.h
//  BoincLaunch
//
//  Created by Nathan Spindel on 8/17/04.
//  Copyright 2004 Nathan Spindel. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface Controller : NSObject {

}

@end
