//
//  main.m
//  BoincLaunch
//
//  Created by Nathan Spindel on 8/17/04.
//  Copyright Nathan Spindel 2004. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
