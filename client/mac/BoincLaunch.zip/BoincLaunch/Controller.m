//
//  Controller.m
//  BoincLaunch
//
//  Created by Nathan Spindel on 8/17/04.
//  Copyright 2004 Nathan Spindel. All rights reserved.
//

#import "Controller.h"


@implementation Controller

// Even though we don't *need* a separate class to do this, for some reason I couldn't get NSRunAlertPanel code
// to work in main.m. Thus the reason for the Controller class
- (void)awakeFromNib
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init]; // memory management pool
    
    // this will be a dictionary of values taken from the xml at ~/Library/Preferences/loginwindow.plist
    NSMutableDictionary *loginPrefs;
    
    // the xml item that will be inserted at the end of loginPrefs
    NSMutableDictionary *loginObject = [[NSMutableDictionary alloc] initWithCapacity:2];
    
    // will be used to replace the old AutoLaunchedApplicationDictionary array
    NSMutableArray *thisArray;
    
    // string of the path to the user's loginwindow.plist
    NSString *loginPrefsPath = [[NSString stringWithString:@"~/Library/Preferences/loginwindow.plist"] stringByExpandingTildeInPath];    
    
    [NSApp activateIgnoringOtherApps:YES];     // force BoincLaunch to have focus
    
    int button = NSRunAlertPanel(@"Launch at Login?",
				 @"If you would like BOINC to launch when you login, please click Yes.\n\nIf not, you can still change this by going to System Preferences > Accounts > Startup Items and adding the file at /Applications/BOINC.term to the list.\n",
				 @"Yes", @"No", nil);
    
    if (NSOKButton == button) { // if the user click "Yes"
	// allocate loginPrefs with the dict at loginPrefsPath
	loginPrefs = [[NSMutableDictionary alloc] initWithContentsOfFile:loginPrefsPath];
	
	// allocate thisArray with the array in loginPrefs's AutoLaunchedApplicationDictionary array
	thisArray = [[NSMutableArray alloc] initWithArray:[loginPrefs objectForKey:@"AutoLaunchedApplicationDictionary"]];
	
	[loginObject setObject:@"/Applications/BOINC.term" forKey:@"Path"]; // set loginObject's path key to a hardcoded path
	[thisArray addObject:loginObject]; // add loginObject to the end of thisArray
	[loginPrefs removeAllObjects]; // remove all items in loginPrefs
	[loginPrefs setObject:thisArray forKey:@"AutoLaunchedApplicationDictionary"]; // reinsert thisArray into loginPrefs
	[loginPrefs writeToFile:loginPrefsPath atomically:YES]; // save loginwindow.plist
    }
    
    [pool release]; // release the autorelease pool
    
    [[NSWorkspace sharedWorkspace] openFile:@"/Applications/BOINC.term"]; // launch the file at the path
    
    [NSApp terminate:(nil)]; // quit BoincLaunch
}

@end
